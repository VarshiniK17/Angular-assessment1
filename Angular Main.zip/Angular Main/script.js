
function goToRegister() {
    window.location.href = "register.html";
  }
  
  function goToReset() {
    window.location.href = "reset.html";
  }
  
 
  function register() {
    var username = document.getElementById("regUsername").value;
    var password = document.getElementById("regPassword").value;
    var retype = document.getElementById("regRetype").value;
  
    if (password !== retype) {
      alert("Passwords do not match.");
      return;
    }
  
    var users = JSON.parse(localStorage.getItem("users")) || [];
  
    var exists = users.find(function(u) {
      return u.username === username;
    });
  
    if (exists) {
      alert("User already exists.");
      return;
    }
  
    users.push({ username: username, password: password });
    localStorage.setItem("users", JSON.stringify(users));
    alert("Registered successfully!");
    window.location.href = "login.html";
  }
  
  
  function login() {
    var username = document.getElementById("loginUsername").value;
    var password = document.getElementById("loginPassword").value;
  
    var users = JSON.parse(localStorage.getItem("users")) || [];
  
    var match = users.find(function(u) {
      return u.username === username && u.password === password;
    });
  
    if (match) {
      localStorage.setItem("loggedInUser", username);
      alert("Login successful!");
      window.location.href = "view.html";
    } else {
      alert("Invalid username or password.");
    }
  }
  
  function checkLogin() {
    var user = localStorage.getItem("loggedInUser");
    if (!user) {
      alert("You must login first.");
      window.location.href = "login.html";
    }
  }
  
  function resetPassword() {
    var username = document.getElementById("resetUsername").value;
    var newPassword = document.getElementById("newPassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
  
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }
  
    var users = JSON.parse(localStorage.getItem("users")) || [];
    var found = false;
  
    for (var i = 0; i < users.length; i++) {
      if (users[i].username === username) {
        users[i].password = newPassword;
        found = true;
        break;
      }
    }
  
    if (found) {
      localStorage.setItem("users", JSON.stringify(users));
      alert("Password updated successfully!");
      window.location.href = "login.html";
    } else {
      alert("User not found.");
    }
  }
  
  
  function addStudent() {
    var name = prompt("Enter student name:");
    var age = prompt("Enter age:");
    var course = prompt("Enter course:");
  
    if (name && age && course) {
      var students = JSON.parse(localStorage.getItem("students")) || [];
      students.push({ name: name, age: age, course: course });
      localStorage.setItem("students", JSON.stringify(students));
      alert("Student added!");
      loadStudents();
    }
  }
 
  function loadStudents() {
    var table = document.getElementById("studentTable");
    var students = JSON.parse(localStorage.getItem("students")) || [];
  
    while (table.rows.length > 1) {
      table.deleteRow(1);
    }
  
    students.forEach(function(s, index) {
      var row = table.insertRow();
      row.insertCell(0).innerText = s.name;
      row.insertCell(1).innerText = s.age;
      row.insertCell(2).innerText = s.course;
      row.insertCell(3).innerHTML =
        '<button onclick="editStudent(' + index + ')">Edit</button> ' +
        '<button onclick="deleteStudent(' + index + ')">Delete</button>';
    });
  }

  function deleteStudent(index) {
    var students = JSON.parse(localStorage.getItem("students")) || [];
    students.splice(index, 1);
    localStorage.setItem("students", JSON.stringify(students));
    loadStudents();
  }
  
  function editStudent(index) {
    var students = JSON.parse(localStorage.getItem("students")) || [];
    var student = students[index];
  
    var name = prompt("Update name:", student.name);
    var age = prompt("Update age:", student.age);
    var course = prompt("Update course:", student.course);
  
    if (name && age && course) {
      students[index] = { name: name, age: age, course: course };
      localStorage.setItem("students", JSON.stringify(students));
      loadStudents();
    }
  }
  